﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;

namespace JalPals.Blocks
{
    public class OuterUpperBlock1 : IBlockState
    {
        private Block myBlock;

        private Rectangle sourceRect = BlockSpriteMap.OuterUpperBlock1;

        public OuterUpperBlock1(Block block)
        {
            myBlock= block;
        }
        public void Update()
        {
            myBlock.BlockState = this;
            myBlock.SourceRect = sourceRect;
            myBlock.BlockState = new OuterUpperBlock1(myBlock);
        }

        public void Draw()
        {

        }
    }
}
