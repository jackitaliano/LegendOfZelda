using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace JalPals.Blocks;

public class Block : IBlock
{
    public IBlockState BlockState{ get; set; }
    public Rectangle SourceRect { get; set; }
    public Vector2 Position { get; set; }
    public Texture2D Texture { get; }

    public Game1 myGame;

    public float myScale;

    public Block(Game1 game, Vector2 position, Texture2D texture, float scale)
    {
        Texture = texture;
        myGame = game;
        Position = position;
        myScale = scale;
        BlockState = new OuterUpperLeftCorner(this);
    }

    public void Update() {
       
        var kstate = Keyboard.GetState();

        if(kstate.IsKeyDown(Keys.NumPad0))
        {
            BlockState = new OuterUpperLeftCorner(this);
        }

        if (kstate.IsKeyDown(Keys.NumPad1))
        {
            BlockState = new OuterUpperBlock1(this);

        }

        if (kstate.IsKeyDown(Keys.NumPad2))
        {
            BlockState = new OuterUpperBlock2(this);
        }

        if (kstate.IsKeyDown(Keys.NumPad3))
        {
            BlockState = new OuterUpperBlock3(this);
        }

        if (kstate.IsKeyDown(Keys.NumPad4))
        {
            BlockState = new OuterUpperBlock4(this);
        }

        if (kstate.IsKeyDown(Keys.NumPad5))
        {
            BlockState = new OuterUpperBlock5(this);
        }


        BlockState.Update();

    }
    public void Draw(SpriteBatch spritebatch) {

        Rectangle sourceRect = SourceRect;
        float width = sourceRect.Width * myScale;
        float height = sourceRect.Height * myScale;
        Rectangle destinationRectangle = new Rectangle((int)Position.X, (int)Position.Y, (int)width, (int)height);
        
        spritebatch.Draw(Texture, destinationRectangle, sourceRect, Color.White);
    }
    public void MoveUp() { }
    public void MoveRight() { }
    public void MoveDown() { }
    public void MoveLeft() { }
}
