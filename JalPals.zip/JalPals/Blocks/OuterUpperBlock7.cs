﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;

namespace JalPals.Blocks
{
    public class OuterUpperBlock7 : IBlockState
    {
        private Block myBlock;

        private Rectangle sourceRect = BlockSpriteMap.OuterUpperBlock7;

        public OuterUpperBlock7(Block block)
        {
            myBlock= block;
        }
        public void Update()
        {
            myBlock.BlockState = this;
            myBlock.SourceRect = sourceRect;
            myBlock.BlockState = new OuterUpperBlock7(myBlock);
        }

        public void Draw()
        {

        }
    }
}
