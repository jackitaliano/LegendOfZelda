﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;

namespace JalPals.Blocks
{
    public class OuterUpperBlock2 : IBlockState
    {
        private Block myBlock;

        private Rectangle sourceRect = BlockSpriteMap.OuterUpperBlock2;

        public OuterUpperBlock2(Block block)
        {
            myBlock= block;
        }
        public void Update()
        {
            myBlock.BlockState = this;
            myBlock.SourceRect = sourceRect;
            myBlock.BlockState = new OuterUpperBlock2(myBlock);
        }

        public void Draw()
        {

        }
    }
}
