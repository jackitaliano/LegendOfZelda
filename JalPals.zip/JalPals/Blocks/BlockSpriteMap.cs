﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;

namespace JalPals.Blocks
{
    public struct BlockSpriteMap
    {
        public BlockSpriteMap() { }

        public static Rectangle OuterUpperLeftCorner = new Rectangle(0, 0, 16, 16);

        public static Rectangle OuterUpperBlock1 = new Rectangle(17, 0, 16, 16);

        public static Rectangle OuterUpperBlock2 = new Rectangle(34, 0, 16, 16);

        public static Rectangle OuterUpperBlock3 = new Rectangle(51, 0, 16, 16);

        public static Rectangle OuterUpperBlock4 = new Rectangle(68, 0, 16, 16);

        public static Rectangle OuterUpperBlock5 = new Rectangle(85, 0, 16, 16);

        public static Rectangle OuterUpperBlock6 = new Rectangle(102, 0, 16, 16);

        public static Rectangle OuterUpperBlock7 = new Rectangle(119, 0, 16, 16);

        public static Rectangle OuterUpperRightCorner = new Rectangle(136, 0, 16, 16);

    }
}
