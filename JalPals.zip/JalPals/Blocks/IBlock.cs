﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace JalPals.Blocks;

public interface IBlock
{
    public IBlockState BlockState { get; set; }
    public Vector2 Position { get; set; }
    public Texture2D Texture { get; }

    public void Update();
    public void Draw(SpriteBatch spritebatch);
    public void MoveUp();
    public void MoveRight();
    public void MoveDown();
    public void MoveLeft();
}
