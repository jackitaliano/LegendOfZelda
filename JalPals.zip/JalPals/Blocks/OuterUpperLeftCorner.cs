﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mime;
using System.Text;
using System.Threading.Tasks;
using JalPals.Player;
using Microsoft.Xna.Framework;

namespace JalPals.Blocks
{
    public class OuterUpperLeftCorner : IBlockState
    {
        private Block myBlock;

        private Rectangle sourceRect = BlockSpriteMap.OuterUpperLeftCorner;

        public OuterUpperLeftCorner(Block block)
        {
            myBlock = block;
        }
        public void Update()
        {
            myBlock.BlockState = this;
            myBlock.SourceRect = sourceRect;
            myBlock.BlockState = new OuterUpperLeftCorner(myBlock);
        }

        public void Draw()
        {

        }
    }
}
