﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;

namespace JalPals.Blocks
{
    public class OuterUpperRightCorner : IBlockState
    {
        private Block myBlock;

        private Rectangle sourceRect = BlockSpriteMap.OuterUpperRightCorner;

        public OuterUpperRightCorner(Block block)
        {
            myBlock= block;
        }
        public void Update()
        {
            myBlock.BlockState = this;
            myBlock.SourceRect = sourceRect;
            myBlock.BlockState = new OuterUpperRightCorner(myBlock);
        }

        public void Draw()
        {

        }
    }
}
