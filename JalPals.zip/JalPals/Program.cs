﻿
using var game = new JalPals.Game1();
game.Run();
