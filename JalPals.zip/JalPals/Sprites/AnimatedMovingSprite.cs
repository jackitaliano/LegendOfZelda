﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
namespace JalPals.Sprites
{
	public class AnimatedMovingSprite : ISprite
	{
        public string ID { get; }
        public Texture2D SpriteSheet { get; set; }
        public Vector2 InitialPosition { get; set; }
        public Vector2 CurrentPosition { get; set; }
        public int Width { get; set; }
        public int Height { get; set; }

        // Movement limits
        public int MaxMoveDistance { get; set; }
        private int step = 1;
        private int direction = 1;

        // Updating animation frames
        private Rectangle CurrentSrcRec;
        private int AnimationFrame = 0;
        private int TotalAnimationFrames = 3;

        // Limit fps of frames
        private int FrameWaitCount = 0;
        private int TotalFrameWaitCount = 12;
        private List<Rectangle> Frames;

        // List of source frames for each animation
        private List<Rectangle> RunRightFrames = new List<Rectangle>(){
            new Rectangle(149, 0, 16, 32),
            new Rectangle(180, 0, 16, 31),
            new Rectangle(209, 1, 16, 30)
        };
        private List<Rectangle> RunLeftFrames = new List<Rectangle>(){
            new Rectangle(60, 0, 16, 32),
            new Rectangle(31, 0, 16, 31),
            new Rectangle(0, 1, 16, 30)
        };

        public AnimatedMovingSprite(string id, Texture2D spriteSheet, Vector2 position, int width, int height, int maxMoveDistance)
        {
            this.ID = id;
            this.SpriteSheet = spriteSheet;
            this.InitialPosition = position;
            this.CurrentPosition = position;
            this.Width = width;
            this.Height = height;
            this.MaxMoveDistance = maxMoveDistance;
            Frames = RunRightFrames;
        }

        public void Update()
        {
            if (!WaitToUpdateFrame())
            {
                CurrentSrcRec = Frames[AnimationFrame];
                RotateAnimationFrame();
            }
            Move();
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            Rectangle destRec = new Rectangle((int)CurrentPosition.X, (int)CurrentPosition.Y, Width, Height);
            spriteBatch.Draw(SpriteSheet, destRec, CurrentSrcRec, Color.White);
        }

        private void Move()
        {
            HandleDirectionChange();

            int newX = (int)CurrentPosition.X + (step * direction);

            CurrentPosition = new Vector2(newX, CurrentPosition.Y);
        }

        private void HandleDirectionChange()
        {
            bool hitRightLimit = CurrentPosition.X > InitialPosition.X + MaxMoveDistance;
            bool hitLeftLimit = CurrentPosition.X < InitialPosition.X - MaxMoveDistance;

            if ( hitRightLimit || hitLeftLimit )
            {
                direction *= -1;
                if (direction == 1)
                    Frames = RunRightFrames;
                else
                    Frames = RunLeftFrames;
            }
        }

        private void RotateAnimationFrame()
        {
            AnimationFrame++;
            if (AnimationFrame >= TotalAnimationFrames)
                AnimationFrame = 0;
        }

        private bool WaitToUpdateFrame()
        {
            FrameWaitCount++;
            if (FrameWaitCount >= TotalFrameWaitCount)
                FrameWaitCount = 0;

            if (FrameWaitCount == 0)
                return false;

            return true;
        }
    }
}

