﻿using System;
namespace JalPals.Sprites
{
	public enum Direction
	{
		Left,
		Right
	}
}

