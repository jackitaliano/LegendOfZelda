﻿using System;
using Microsoft.Xna.Framework.Graphics;

namespace JalPals.Sprites
{
	public interface ISprite
	{
		void Update();
		void Draw(SpriteBatch spriteBatch);
	}
}

