﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

using static System.Formats.Asn1.AsnWriter;

namespace JalPals.Player
{
	public class LinkHealth : ILinkHealth
	{
        public float HeartsLeft;
        private Rectangle HeartSourceRectangle = new Rectangle(244, 199, 7, 8);
        private static List<Rectangle> HeartDestinationRectangles = new List<Rectangle>() {
            new Rectangle(500, 25, 14, 16),
            new Rectangle(525, 25, 14, 16),
            new Rectangle(550, 25, 14, 16),
            new Rectangle(575, 25, 14, 16),
        };
        public Texture2D Texture;
        public int LinkHealthVal { get; set; }

        public LinkHealth(Texture2D texture)
		{
            HeartsLeft = 4;
            this.Texture = texture;
		}

        

        public void Draw(SpriteBatch spriteBatch)
        {
            for(int i=0; i < HeartsLeft; i++)
            {
                spriteBatch.Draw(Texture, HeartDestinationRectangles[i], HeartSourceRectangle, Color.White);
            }
            
        }

        public void RemoveHealth()
        {
            HeartsLeft--;
        }

        public void AddHealth()
        {
            HeartsLeft++;
        }

        public void ResetHealth()
        {
            HeartsLeft = 4;
        }
    }
}

