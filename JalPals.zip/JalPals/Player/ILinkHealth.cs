﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace JalPals.Player;

public interface ILinkHealth
{
    public int LinkHealthVal{ get; set; }
    void Draw(SpriteBatch spriteBatch);
    void RemoveHealth();
    void AddHealth();
    void ResetHealth();

}

