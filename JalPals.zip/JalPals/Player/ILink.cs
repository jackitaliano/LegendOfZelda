﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace JalPals.Player;

public interface ILink
{
    public ILinkState LinkState { get; set; }
    public Rectangle SourceRect { get; set; }
    public Vector2 Position { get; set; }
    public Vector2 Dimensions { get; set; }
    public Texture2D Texture { get; }


    public int StepDistance { get; }

    void Update();
    void Draw(SpriteBatch spriteBatch);
    void Idle();
    void MoveUp();
    void MoveRight();
    void MoveDown();
    void MoveLeft();
    void Hit();
    void Sword();
    void Wand();
    void TakeDamage();
}

