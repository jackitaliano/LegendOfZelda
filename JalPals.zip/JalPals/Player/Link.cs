﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace JalPals.Player;

public class Link : ILink
{
	public ILinkState LinkState { get; set; }
    public ILinkHealth LinkHealth { get; set; }
	public Rectangle SourceRect { get; set; }
	public Vector2 Position { get; set; }
	public Vector2 Dimensions { get; set; }
	public Texture2D Texture { get; }

    public int StepDistance { get; } = 2;
    private float scale;

	public Link(Texture2D texture, Vector2 position, float scale)
	{
		this.Texture = texture;
		this.Position = position;
        this.scale = scale;

		LinkState = new LinkIdleState(this);
        //Might Need Changing
        LinkHealth = new LinkHealth(Texture);
	}

    public void Update()
    {
        LinkState.Update();
        UpdateAnimation();
    }

    public void Draw(SpriteBatch spriteBatch)
    {
        Rectangle srcRect = SourceRect;
        float width = SourceRect.Width * scale;
        float height = SourceRect.Height * scale;
        Rectangle destRect = new Rectangle((int)Position.X, (int)Position.Y, (int)width, (int)height);

        spriteBatch.Draw(Texture, destRect, srcRect, Color.White);
        LinkHealth.Draw(spriteBatch);
    }

    private void UpdateAnimation()
    {
        int animationFrame = LinkState.AnimationFrame;
        animationFrame++;
        if (animationFrame >= LinkState.MaxAnimationFrames)
            animationFrame = 0;
        LinkState.AnimationFrame = animationFrame;
    }

    public void Idle()
    {
        LinkState.Idle();
    }

    public void MoveLeft()
    {
        LinkState.MoveLeft();
    }

    public void MoveRight()
    {
        LinkState.MoveRight();
    }

    public void MoveUp()
    {
        LinkState.MoveUp();
    }

    public void MoveDown()
    {
        LinkState.MoveDown();
    }

    public void Hit()
    {
        LinkState.Hit();
    }

    public void Sword()
    {
        LinkState.Sword();
    }

    public void Wand()
    {
        LinkState.Wand();
    }

    public void TakeDamage()
    {
        LinkState.TakeDamage();
        LinkHealth.RemoveHealth();
    }
}

