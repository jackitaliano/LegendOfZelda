﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;

namespace JalPals.Player;

public class LinkWalkingDownState : ILinkState
{
	public int MaxAnimationFrames { get; }
    public int AnimationFrame { get { return animationFrame; } set { animationFrame = value; } }

    private int animationFrame;

    private ILink link;
	private int stepDistance;

	private List<Rectangle> animation = LinkAnimations.WalkingDown;

    public LinkWalkingDownState(ILink link)
	{
		this.link = link;
        animationFrame = 0;
        MaxAnimationFrames = animation.Count;
		stepDistance = link.StepDistance;
	}

	public void Update()
	{
		link.SourceRect = animation[animationFrame];
	}

	public void Idle()
	{
		animationFrame = 0;
	}

	public void MoveUp()
	{
		link.LinkState = new LinkWalkingUpState(link);
	}

	public void MoveRight()
	{
		link.LinkState = new LinkWalkingRightState(link);
	}

	public void MoveDown()
	{
		Vector2 position = link.Position;

		position.Y = position.Y + stepDistance;

		link.Position = position;
	}

	public void MoveLeft()
	{
		link.LinkState = new LinkWalkingLeftState(link);
	}

	public void Hit()
	{
		link.LinkState = new LinkHitDownState(link);
    }

    public void Sword()
    {
		link.LinkState = new LinkSwordDownState(link);
    }

    public void Wand()
    {
        link.LinkState = new LinkWandDownState(link);
    }

    public void TakeDamage()
    {
        link.LinkState = new LinkTakeDamageState(link);
    }
}

