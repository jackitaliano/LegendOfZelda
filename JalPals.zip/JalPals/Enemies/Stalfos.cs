﻿using System;
using Microsoft.Xna.Framework.Graphics;
using System.Collections.Generic;
using Microsoft.Xna.Framework;

namespace JalPals.Sprites
{
	public class Stalfos : ISprite
	{
        public Texture2D SpriteSheet { get; set; }
        int AnimationFrame;
        public Vector2 CurrentPosition { get; set; }

        public Stalfos(Texture2D spriteSheet, Vector2 position)
		{
            this.CurrentPosition = position;
            this.SpriteSheet = spriteSheet;
        }

        public void Update()
		{

		}

        public void Draw(SpriteBatch spriteBatch)
		{
            Rectangle destRec = new Rectangle((int)CurrentPosition.X, (int)CurrentPosition.Y, 16, 16);
            Rectangle srcRec = new Rectangle(1, 59, 16, 16);
            spriteBatch.Draw(this.SpriteSheet, destRec, srcRec, Color.White);
        }
    }
}

