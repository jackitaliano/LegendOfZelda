﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;
using System.Collections.Generic;
using JalPals.Commands;
namespace JalPals.Controllers
{
	public class KeyboardController : IController
	{
        private KeyboardState currentState;
        private KeyboardState previousState;

        private CommandManager commandManager;
        private Dictionary<Keys, ICommand> commandMap;

        private ICommand defaultCommand;

		public KeyboardController(Game1 game, CommandManager commandManager)
        {
            this.commandManager = commandManager;
            this.currentState = Keyboard.GetState();
            this.previousState = Keyboard.GetState();

            defaultCommand = new LinkIdle(game);

            commandMap = new Dictionary<Keys, ICommand>()
            {
                { Keys.Right, new LinkMoveRight(game) },
                { Keys.D, new LinkMoveRight(game) },

                { Keys.Left, new LinkMoveLeft(game) },
                { Keys.A, new LinkMoveLeft(game) },

                { Keys.Up, new LinkMoveUp(game) },
                { Keys.W, new LinkMoveUp(game) },

                { Keys.Down, new LinkMoveDown(game) },
                { Keys.S, new LinkMoveDown(game) },

                { Keys.E, new LinkTakeDamage(game) },
                { Keys.T, new LinkWand(game) },
                { Keys.D1, new LinkHit(game) },
                { Keys.D2, new LinkWand(game) },


                { Keys.Q, new LinkSword(game) },
                { Keys.Z, new LinkSword(game) },
                { Keys.N, new LinkSword(game) }

            };
        }

		public void Update()
		{
            // Update current keyboard state
            currentState = Keyboard.GetState();

            // Check if valid current state
            //if (ValidCurrentState())
            HandleState();

            // Update previous keyboard state
            previousState = currentState;
        }

        private void HandleState()
        {
            Keys[] keysPressed = currentState.GetPressedKeys();

            if (keysPressed.Length == 0)
            {
                commandManager.AddNewCommand(defaultCommand);
                return;
            }

            foreach (var key in keysPressed)
            {
                if (commandMap.ContainsKey(key))
                {
                    ICommand command = commandMap[key];
                    commandManager.AddNewCommand(command);
                }
            }
        }

        private bool ValidCurrentState()
        {
            // Check state has changed
            return currentState != previousState;
        }
    }
}

