﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using JalPals.Commands;
using JalPals.Controllers;
using JalPals.Player;
using System;
using System.Threading;
using JalPals.Blocks;

namespace JalPals;

public class Game1 : Game
{
    private GraphicsDeviceManager _graphics;
    private SpriteBatch _spriteBatch;
    private IController keyboardController;
    private IController mouseController;
    private CommandManager commandManager;
    public ILink Link { get; set; }
    public IBlock myBlock;

    //private string creditsText = "Credits\nProgram Made By: Jack Italiano\nSprites from: mariouniverse.com/wp-content/img/sprites/nes/smb/mario.png";

    public Game1()
    {
        _graphics = new GraphicsDeviceManager(this);
        Content.RootDirectory = "Content";
        IsMouseVisible = true;
    }

    protected override void Initialize()
    {
        // Initialize managers
        commandManager = new CommandManager(this);

        // Initialize controllers
        keyboardController = new KeyboardController(this, commandManager);
        mouseController = new MouseController(this, commandManager);

        base.Initialize();
    }

    protected override void LoadContent()
    {
        _spriteBatch = new SpriteBatch(GraphicsDevice);

        // Initialize textures
        //SpriteFont gameFont = Content.Load<SpriteFont>("Font");
        Texture2D LinkMovementTexture = Content.Load<Texture2D>("link");
        Texture2D BlockTexture = Content.Load<Texture2D>("blockSpriteMap");

        Vector2 position = new Vector2(100, 100);
        Vector2 blockPosition = new Vector2(200, 100);
        float scale = 5.0f;
        Link = new Link(LinkMovementTexture, position, scale);
        myBlock = new Block(this, blockPosition, BlockTexture, scale);
    }

    protected override void Update(GameTime gameTime)
    {
        if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
            Exit();

        keyboardController.Update();
        mouseController.Update();
        commandManager.Update();
        Link.Update();
        myBlock.Update();

        base.Update(gameTime);
    }

    protected override void Draw(GameTime gameTime)
    {

        // Limit the frame rate to 30 frames per second
        float targetFrameTime = 1.0f / 30.0f;

        Thread.Sleep((int)(targetFrameTime * 1000));

        GraphicsDevice.Clear(Color.CornflowerBlue);

        _spriteBatch.Begin();
        Link.Draw(_spriteBatch);
        myBlock.Draw(_spriteBatch);
        _spriteBatch.End();

        base.Draw(gameTime);
    }
}
