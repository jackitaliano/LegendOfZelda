﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using JalPals.Items;

namespace JalPals.Items
{
	public interface IItemManager
	{
		public IList<IItem> ItemsInFrame { get; set;}

		void Draw(SpriteBatch spriteBatch);
		void Update();
		void AddItem(IItem item);
		void DeleteItem(IItem item);
	}
}

