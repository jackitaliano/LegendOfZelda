﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace JalPals.Items
{
    public class ItemManager : IItemManager
    {
        public IList<IItem> ItemsInFrame { get; set; }
        private SpriteBatch _spriteBatch;

        public ItemManager (SpriteBatch SpriteBatch) {

            this._spriteBatch = SpriteBatch;
            this.ItemsInFrame = new List<IItem>();
        }

        public ItemManager()
        {
            this.ItemsInFrame = new List<IItem>();
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            foreach (IItem Item in ItemsInFrame)
            {
                Item.Draw(spriteBatch);
            }
        }

        public void Update()
        {
            foreach (IItem Item in ItemsInFrame)
            {
                Item.Update();
            }
            
        }
        public void DeleteItem(IItem item)
        {
            this.ItemsInFrame.Remove(item);
        }

        public void AddItem(IItem item)
        {
            this.ItemsInFrame.Add(item);
        }
    }
}
