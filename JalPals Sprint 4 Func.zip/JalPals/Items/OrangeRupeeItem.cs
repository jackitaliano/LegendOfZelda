﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace JalPals.Items;

public class OrangeRupeeItem : IItem
{
    
    public Rectangle SourceRect { get; set; }
    public Rectangle destRectangle { get; set; }
    public Rectangle collisionRectangle { get; set; }
    public Vector2 velocityVector { get; set; }
    public Vector2 Position { get; set; }
    public Vector2 Dimensions { get; set; }
    public Texture2D Texture { get; }
    public float scale { get; }
    public bool InInventory { get; set; }
    public bool ItemStatus { get; set; }


    public OrangeRupeeItem(Texture2D Texture, Vector2 Position, float Scale)
    {
        this.SourceRect = ItemAnimations.OrangeRupeeItem;
        this.Texture = Texture;
        this.Position = Position;
        this.scale = Scale / 2;
        this.InInventory = false;
        int width = (int) (SourceRect.Width * scale);
        int height = (int)(SourceRect.Height * scale);
        destRectangle = new Rectangle((int)Position.X, (int)Position.Y, width, height);
        collisionRectangle = destRectangle;

    }

    public void Draw(SpriteBatch spriteBatch)
    {
        if (InInventory)
        {
            spriteBatch.Draw(Texture, ItemSlots.Slot2, SourceRect, Color.White);
        }
        else
        {
            spriteBatch.Draw(Texture, destRectangle, SourceRect, Color.White);
        }
    }
    public void Update()
    {

    }

    public GameObjectType getType()
    {
        return GameObjectType.ITEM;
    }

    public void ResolveCollision(IGameObject obj1, int side)
    {

    }

}
