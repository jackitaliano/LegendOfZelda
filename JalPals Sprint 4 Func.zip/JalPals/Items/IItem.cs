﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using JalPals.Inventory;

namespace JalPals.Items;

public interface IItem : IGameObject
{
    public Rectangle SourceRect { get; set; }
    public Vector2 Position { get; set; }
    public Vector2 Dimensions { get; set; }
    public Texture2D Texture { get; }
    public bool InInventory { get; set; }
    public bool ItemStatus { get; set; }

    void Draw(SpriteBatch spriteBatch);
    void Update();
}
