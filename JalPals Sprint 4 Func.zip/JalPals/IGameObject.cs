﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
namespace JalPals;

public enum GameObjectType {
	LINK,
	ENEMY,
	BLOCK,
	LINKPROJECTILE,
	ENEMYPROJECTILE,
	ITEM,
	TEXT,
	WALL

}

public interface IGameObject
{
	public Rectangle collisionRectangle { get; set; }
	public Vector2 velocityVector { get; set; }
	public void ResolveCollision(IGameObject obj, int side);
	public GameObjectType getType();
}

