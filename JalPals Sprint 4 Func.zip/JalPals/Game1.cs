﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using JalPals.Commands;
using JalPals.Controllers;
using JalPals.Player;
using System;
using System.Threading;
using JalPals.Blocks2;
using JalPals.Rooms;
using JalPals.Sprites;
using JalPals.Enemies;
using JalPals.Items;
using JalPals.HUD;
using JalPals.Projectiles;
using JalPals.Collision;
using System.Collections.Generic;
using System.IO;
using static System.Net.Mime.MediaTypeNames;
using System.Reflection;

namespace JalPals;

public class Game1 : Game
{
    private GraphicsDeviceManager _graphics;
    private SpriteBatch _spriteBatch;
    private IController keyboardController;
    private IController mouseController;
    private CommandManager commandManager;
    private CollisionManager collisionManager;
    private SpriteFont gameFont;

    public ILink Link { get; set; }
    public IEnemySwitcher enemySwitcher { get; set; }
    public IItemManager itemManager { get; set; }
    public IProjectileManager projManager { get; set; }
    public IRoomManager roomManager { get; set; }
    public IMenu menu { get; set; }
    GameTime gameTime;

    Texture2D whiteRectangle;

    public Game1()
    {
        _graphics = new GraphicsDeviceManager(this);

        // Set screen size to 3x native resolution
        _graphics.PreferredBackBufferWidth = 256*3;
        _graphics.PreferredBackBufferHeight = 240*3;
        _graphics.ApplyChanges();

        Content.RootDirectory = "Content";
        IsMouseVisible = true;
    }

    protected override void Initialize()
    {
        // Initialize managers
        commandManager = new CommandManager(this);
        collisionManager = new CollisionManager();

        // Initialize controllers
        keyboardController = new KeyboardController(this, commandManager);
        mouseController = new MouseController(this, commandManager);

        base.Initialize();
    }

    protected override void LoadContent()
    {
        _spriteBatch = new SpriteBatch(GraphicsDevice);

        // Initialize textures
        gameFont = Content.Load<SpriteFont>("Zelda");
        Texture2D LinkMovementTexture = Content.Load<Texture2D>("link");
        Texture2D EnemyTexture = Content.Load<Texture2D>("dungeonEnemiesTransparent");

        Vector2 position = new Vector2(364, 552);
        Vector2 enemyPos = new Vector2(380, 240);
        Vector2 blockPosition = new Vector2(20, 200);
        
        float scale = 3.0f;

        projManager = new ProjectileManager(Content);
        itemManager = new ItemManager(_spriteBatch);

        Link = new Link(LinkMovementTexture, position, scale, projManager, itemManager);

        Link.LinkState = new LinkWalkingUpState(Link);


        enemySwitcher = new EnemySwitcher(Content, enemyPos, projManager);

        string workingDirectory = Environment.CurrentDirectory;
        string projectDirectory = Directory.GetParent(workingDirectory).Parent.Parent.FullName;
        string[] roomFiles = Directory.GetFiles(projectDirectory + "/Content/csv");

        roomManager = new RoomManager(roomFiles, Content, (int)scale);
        menu = new Menu(Content);


        whiteRectangle = new Texture2D(GraphicsDevice, 1, 1);
        whiteRectangle.SetData(new[] { Color.White });
    }

    protected override void Update(GameTime gameTime)
    {
        if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
            Exit();

        collisionManager.UpdateGameObjects(GetUpdatedGameObjectLists(), enemySwitcher.currentEnemy, Link);
        collisionManager.HandleCollisions();

        keyboardController.Update();
        mouseController.Update();
        commandManager.Update();
        Link.Update();
        enemySwitcher.Update();
        itemManager.Update();
        projManager.Update();
        roomManager.Update();

        base.Update(gameTime);
    }

    protected override void Draw(GameTime gameTime)
    {

        // Limit the frame rate to 30 frames per second
        float targetFrameTime = 1.0f / 30.0f;

        Thread.Sleep((int)(targetFrameTime * 1000));

        GraphicsDevice.Clear(Color.Black);

        _spriteBatch.Begin(samplerState: SamplerState.PointClamp);

        roomManager.Draw(_spriteBatch);
        Link.Draw(_spriteBatch);
        enemySwitcher.Draw(_spriteBatch);
        itemManager.Draw(_spriteBatch);
        projManager.Draw(_spriteBatch);
        menu.Draw(_spriteBatch);
        

        foreach (IGameObject gameObj in roomManager.currentRoom.collideable)
        {
            _spriteBatch.Draw(whiteRectangle, gameObj.collisionRectangle, Color.White);
        }

        _spriteBatch.End();


        base.Draw(gameTime);
    }

    private List<List<IGameObject>> GetUpdatedGameObjectLists()
    {
        List<IGameObject> projList = new List<IGameObject>(projManager.projectiles);
        List<IGameObject> itemList = new List<IGameObject>(itemManager.ItemsInFrame);
        List<IGameObject> blockList = new List<IGameObject>(roomManager.currentRoom.collideable);
        List<IGameObject> wallColList = new List<IGameObject>(roomManager.currentRoom.wallRectangles);
        List<List<IGameObject>> objectLists = new List<List<IGameObject>>
        {
            projList,
            itemList,
            blockList,
            wallColList
        };

        return objectLists;
    }
}
