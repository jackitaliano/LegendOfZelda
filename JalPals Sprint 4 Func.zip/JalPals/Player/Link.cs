﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using JalPals.Inventory;
using JalPals.Items;
using JalPals.Projectiles;

namespace JalPals.Player;

public class Link : ILink
{
    public ILinkState LinkState { get; set; }
    public ILinkHealth LinkHealth { get; set; }
    public IInventory LinkInventory { get; }
    public IItemManager LinkItemManager { get; set; }
    public IProjectileManager LinkProjManager { get; set; }


    public Rectangle SourceRect { get; set; }
    public Rectangle destRectangle { get; set; }
    public Rectangle collisionRectangle { get; set; }
    public Vector2 velocityVector { get; set; }
    public float Scale { get { return scale; } }

    public Vector2 Position { get; set; }
	public Vector2 Dimensions { get { return new Vector2(SourceRect.Width * scale, SourceRect.Height * scale); } }
	public Texture2D Texture { get; }

    public int StepDistance { get; } = 4;
    private float scale;
    private int currentFrame;
    GameTime gameTime;



    public Link(Texture2D texture, Vector2 position, float scale, IProjectileManager projManager, IItemManager itemManager)
	{
		this.Texture = texture;
		this.Position = position;
        this.scale = scale;

        float width = SourceRect.Width * scale;
        float height = SourceRect.Height * scale;
        destRectangle = new Rectangle((int)Position.X, (int)Position.Y, (int)width, (int)height);
        collisionRectangle = destRectangle;

        LinkState = new LinkWalkingUpState(this);
        LinkHealth = new LinkHealth(Texture);
        LinkInventory = new LinkInventory(Texture);

        LinkItemManager = itemManager;
        LinkProjManager = projManager;
	}

    public void Update()
    {
        LinkState.Update();
        destRectangle = new Rectangle((int)Position.X, (int)Position.Y, (int)(SourceRect.Width * scale), (int)(SourceRect.Width * scale));
        collisionRectangle = destRectangle;
    }

    public void Draw(SpriteBatch spriteBatch)
    {
        Rectangle srcRect = SourceRect;
        Rectangle destRect = new Rectangle((int)Position.X, (int)Position.Y, (int)Dimensions.X, (int)Dimensions.Y);

        spriteBatch.Draw(Texture, destRect, srcRect, Color.White);
        LinkHealth.Draw(spriteBatch);
        LinkInventory.Draw(spriteBatch);
    }

    public void Idle()
    {
        LinkState.Idle();
    }
    public void MoveLeft()
    {
        LinkState.MoveLeft();
    }

    public void MoveRight()
    {
        LinkState.MoveRight();
    }

    public void MoveUp()
    {
        LinkState.MoveUp();
    }

    public void MoveDown()
    {
        LinkState.MoveDown();
    }

    public void Hit()
    {
        LinkState.Hit();
    }

    public void Sword()
    {
        LinkState.Sword();
    }

    public void Wand()
    {
        LinkState.Wand();
    }

    public void TakeDamage()
    {
        LinkState.TakeDamage();
        LinkHealth.RemoveHealth();
    }

    public void PickupItem(IItem item)
    {
        LinkState.PickupItem();
        LinkItemManager.DeleteItem(item);
        LinkInventory.AddItem(item);
    }

    public void UseArrow()
    {
        LinkProjManager.AddArrowRight(Position, scale, true);
    }

    public void UseBoomerang()
    {
        LinkProjManager.AddBoomerang(Position, new Vector2(5, 0), true);
    }

    public void UseFireball()
    {
        LinkProjManager.AddFireball(Position, new Vector2(2, 0), true);
    }

    public GameObjectType getType()
    {
        return GameObjectType.LINK;
    }

    public void ResolveCollision(IGameObject obj1, int side)
    {
        GameObjectType type = obj1.getType();
        switch (type)
        {
            case GameObjectType.ENEMY:
                CollideEnemy(obj1, side);
                break;
            case GameObjectType.ENEMYPROJECTILE:
                CollideEnemyProjectile(obj1, side);
                break;
            case GameObjectType.LINKPROJECTILE:
                CollideFriendlyProjectile(obj1, side);
                break;
            case GameObjectType.ITEM:
                CollideItem(obj1, side);
                break;
            case GameObjectType.BLOCK:
                CollideBlock(obj1, side);
                break;
            case GameObjectType.WALL:
                CollideWall(obj1, side);
                break;
        }
    }


    private void CollideEnemy(IGameObject enemy, int side)
    {
        CollisionRebound(side);
    }

    private void CollideEnemyProjectile(IGameObject projectile, int side)
    {
        Console.WriteLine("enemy proj");
        TakeDamage();
    }

    private void CollideFriendlyProjectile(IGameObject obj1, int side)
    {
        
    }

    private void CollideItem(IGameObject obj1, int side)
    {
        PickupItem((IItem) obj1);
    }

    private void CollideBlock(IGameObject obj1, int side)
    {
        Console.WriteLine("collide block");
        CollisionRebound(side);
    }

    private void CollideWall(IGameObject obj1, int side)
    {
        CollisionRebound(side);
    }

    private void CollisionRebound(int side)
    {
        switch(side)
        {
            case 1: // Top side
                Position = new Vector2(Position.X, Position.Y + StepDistance);
                break;
            case 2: // Right side
                Position = new Vector2(Position.X - StepDistance, Position.Y);
                break;
            case 3: // Bottom side
                Position = new Vector2(Position.X, Position.Y - StepDistance);
                break;
            case 4: // Left side
                Position = new Vector2(Position.X + StepDistance, Position.Y);
                break;
        }
    }
}

