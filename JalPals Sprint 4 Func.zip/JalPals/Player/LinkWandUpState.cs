﻿using System;
using System.Collections.Generic;

using Microsoft.Xna.Framework;

namespace JalPals.Player;

public class LinkWandUpState : ILinkState
{
    public int MaxAnimationFrames { get; }
    public int AnimationFrame { get { return animationFrame; } set { animationFrame = value; } }

    private int animationFrame;

    private ILink link;

    private int stepDistance;
    private Vector2 dimensions;

    private List<Rectangle> animation = LinkAnimations.WandUp;

    public LinkWandUpState(ILink link)
    {
        this.link = link;
        animationFrame = 0;
        MaxAnimationFrames = animation.Count;

        stepDistance = link.StepDistance;
        float width = animation[animationFrame].Width * link.Scale;
        float height = animation[animationFrame].Height * link.Scale - link.Dimensions.Y;

        this.dimensions = new Vector2(width, height);

        link.Position = new Vector2(link.Position.X, link.Position.Y - dimensions.Y);
    }

    public void Update()
    {
        link.SourceRect = animation[animationFrame];
        UpdateAnimation();
    }

    private void UpdateAnimation()
    {
        AnimationFrame++;
        if (AnimationFrame >= MaxAnimationFrames)
        {
            link.Position = new Vector2(link.Position.X, link.Position.Y + dimensions.Y);
            link.LinkState = new LinkWalkingUpState(link);
        }
    }

    public void Idle()
    {
        // NO-OP
    }

    public void MoveUp()
    {
        // NO-OP
    }

    public void MoveRight()
    {
        // NO-OP
    }

    public void MoveDown()
    {
        // NO-OP
    }

    public void MoveLeft()
    {
        // NO-OP
    }

    public void Hit()
    {
        // NO-OP
    }

    public void Sword()
    {
        // NO-OP
    }

    public void Wand()
    {
        // NO-OP
    }

    public void TakeDamage()
    {
        link.LinkState = new LinkTakeDamageState(link);
    }

    public void PickupItem()
    {
        // Fill
    }
}
