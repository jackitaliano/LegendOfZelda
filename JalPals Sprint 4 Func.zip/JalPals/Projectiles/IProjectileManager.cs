﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace JalPals.Projectiles
{
	public interface IProjectileManager
	{
		List<IProjectile> projectiles { get; set; }
		void AddFireball(Vector2 position, Vector2 velocity, bool isFriendly);
        void AddBoomerang(Vector2 position, Vector2 velocity, bool isFriendly);
        void AddArrowRight(Vector2 position, float scale, bool isFriendly);
		void RemoveItem(IProjectile projectile);
		void Update();
		void Draw(SpriteBatch spriteBatch);
    }

}

