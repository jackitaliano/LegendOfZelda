﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using JalPals.Projectiles;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;
using JalPals.Items;
using static System.Formats.Asn1.AsnWriter;

namespace JalPals.Projectiles
{
	public class ProjectileManager : IProjectileManager
	{
		// Properties
        public List<IProjectile> projectiles { get; set; }

        // Private variables
        private Texture2D enemyTexture;
        private Texture2D bossTexture;
        private Texture2D linkTexture;


        public ProjectileManager(ContentManager content)
		{
            enemyTexture = content.Load<Texture2D>("dungeonEnemiesTransparent");
            bossTexture = content.Load<Texture2D>("bosses");
            linkTexture = content.Load<Texture2D>("link");
            projectiles = new List<IProjectile>();
		}

		public void AddFireball(Vector2 position, Vector2 velocity, bool isFriendly)
		{
			projectiles.Add(new Fireball(bossTexture, position, velocity, isFriendly));
		}

		public void AddBoomerang(Vector2 position, Vector2 velocity, bool isFriendly)
		{
            projectiles.Add(new Boomerang(enemyTexture, position, velocity, isFriendly));
        }

        public void AddArrowRight(Vector2 position, float scale, bool isFriendly)
		{
            projectiles.Add(new GreenArrowRight(linkTexture, position, scale, isFriendly));
        }

        public void RemoveItem(IProjectile projectile)
        {
            projectiles.Remove(projectile);
        }

		public void Update()
		{
			for (int i = 0; i < projectiles.Count; i++) {
                if (projectiles[i].Visible) {
                    projectiles[i].Update();

                } else {
                    projectiles.RemoveAt(i);
                }
            }
        }


		public void Draw(SpriteBatch spriteBatch)
		{
            foreach (IProjectile projectile in projectiles)
            {
                projectile.Draw(spriteBatch);
            }
        }
	}
}

