﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;
using System.Collections.Generic;
using JalPals.Commands;

namespace JalPals.Controllers
{
	public class KeyboardController : IController
	{
        private KeyboardState currentState;
        private KeyboardState previousState;

        private CommandManager commandManager;
        private Dictionary<Keys, ICommand> heldCommands;
        private Dictionary<Keys, ICommand> pressedCommands;

        private ICommand defaultCommand;

		public KeyboardController(Game1 game, CommandManager commandManager)
        {
            this.commandManager = commandManager;
            this.currentState = Keyboard.GetState();
            this.previousState = Keyboard.GetState();

            defaultCommand = new LinkIdle(game);

            heldCommands = new Dictionary<Keys, ICommand>()
            {
                { Keys.Right, new LinkMoveRight(game) },
                { Keys.D, new LinkMoveRight(game) },

                { Keys.Left, new LinkMoveLeft(game) },
                { Keys.A, new LinkMoveLeft(game) },

                { Keys.Up, new LinkMoveUp(game) },
                { Keys.W, new LinkMoveUp(game) },

                { Keys.Down, new LinkMoveDown(game) },
                { Keys.S, new LinkMoveDown(game) },
                { Keys.Q, new ExitCommand(game) },
            };

            pressedCommands = new Dictionary<Keys, ICommand>()
            {
                { Keys.E, new LinkTakeDamage(game) },

                { Keys.L, new LinkWand(game) },
                { Keys.D1, new LinkHit(game) },
                { Keys.D2, new LinkShootBoomerang(game) },
                { Keys.D3, new LinkShootArrow(game) },
                { Keys.D4, new LinkShootFireball(game) },

                { Keys.Z, new LinkWand(game) },
                { Keys.N, new LinkSword(game) },

                {Keys.U, new SwapItemLeft(game) },
                {Keys.I, new SwapItemRight(game) },

                {Keys.P, new NextEnemy(game) },
                {Keys.O, new PreviousEnemy(game) }
            };
        }

		public void Update()
		{
            // Update current keyboard state
            currentState = Keyboard.GetState();

            // Check if valid current state
            //if (ValidCurrentState())
            HandleState();

            // Update previous keyboard state
            previousState = currentState;
        }

        private void HandleState()
        {
            Keys[] keysPressed = currentState.GetPressedKeys();
           

            if (keysPressed.Length == 0)
                return;

            foreach (var key in keysPressed)
            {
                ICommand command = GetCommand(key);
                commandManager.AddNewCommand(command);
            }
        }

        private ICommand GetCommand(Keys key)
        {
            if (pressedCommands.ContainsKey(key) && !RepeatState())
                return pressedCommands[key];
            if (heldCommands.ContainsKey(key))
                return heldCommands[key];
            return defaultCommand;
        }

        private bool RepeatState()
        {
            // Check state has changed
            return currentState == previousState;
        }
    }
}

