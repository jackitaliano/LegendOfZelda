﻿using System;
namespace JalPals.Controllers
{
	public interface IController
	{
		void Update();
	}
}

