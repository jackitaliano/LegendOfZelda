﻿using System;
using Microsoft.Xna.Framework.Graphics;

namespace JalPals.Doors
{
    public enum DoorSide
    {
        TOP,
        LEFT,
        RIGHT,
        BOTTOM
    }
    public interface IDoor : IGameObject
    {

        public DoorSide doorSide { get;}
        public Boolean isOpen { get; set; }
        void Draw(SpriteBatch spriteBatch);
    }
}

