﻿using System;
using JalPals.Doors;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace JalPals.Doors
{
    public class Door : IDoor
    {
   

        // Public properties
        public DoorSide doorSide { get; }
        public Rectangle destRectangle { get; set; }
        public Rectangle collisionRectangle { get; set; }
        public Rectangle srcRectangle { get; set; }
        public Vector2 velocityVector { get; set; }
        public bool collidable { get; set; }
        public bool isOpen { get; set; }

        // Private variables
        Texture2D spriteSheet;

        public Door(Texture2D spriteSheet, Rectangle src, Rectangle dest, bool isOpen, DoorSide side)
        {
            this.spriteSheet = spriteSheet;
            this.destRectangle = dest;
            this.srcRectangle = src;
            this.isOpen = isOpen;
            this.doorSide = side;
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(this.spriteSheet, destRectangle, srcRectangle, Color.White);
        }


        public GameObjectType getType()
        {
            return GameObjectType.BLOCK;

        }

        public void ResolveCollision(IGameObject obj, int side)
        {
            throw new NotImplementedException();
        }
    }
}

