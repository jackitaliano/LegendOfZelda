﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework.Graphics;

namespace JalPals.Rooms
{
	public interface IRoomManager
	{
        public SortedDictionary<int, IRoom> rooms { get; set; }
        public IRoom currentRoom { get; set; }
        void Update();
        void Draw(SpriteBatch spriteBatch);
        void Next();
        void Previous();
        
    }

}

