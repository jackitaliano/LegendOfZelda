﻿using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;

namespace JalPals.Rooms
{
	public class RoomManager : IRoomManager
	{
		public SortedDictionary<int, IRoom> rooms { get; set; }
		public IRoom currentRoom { get; set; }

        private int index;
		private int roomCount;

        public RoomManager(string[] filePaths, ContentManager content, int scale)
		{
			rooms = new SortedDictionary<int, IRoom>();
			index = 0;

			foreach(String filePath in filePaths)
			{
                int id;
                using (var reader = new StreamReader(filePath))
                {
                    id = Int32.Parse(reader.ReadLine().Split(',')[0]);
                }
				rooms.Add(id, new Room(filePath, content, scale));
			}

            currentRoom = rooms[index];
            roomCount = rooms.Count;
		}

		public void Update()
		{
            currentRoom.Update();
		}

		public void Draw(SpriteBatch spriteBatch)
		{
			currentRoom.Draw(spriteBatch);

		}
		public void Next()
		{
            if (index == roomCount - 1)
            {
                index = 0;
            }
            else
            {
                index++;
            }
            currentRoom = rooms[index];

            Console.WriteLine("Room ID: {0}", index);
        }

        public void Previous()
        {

            if (index == 0)
            {
                index = roomCount - 1;
            }
            else
            {
                index--;
            }
            currentRoom = rooms[index];
        }

	}
}

