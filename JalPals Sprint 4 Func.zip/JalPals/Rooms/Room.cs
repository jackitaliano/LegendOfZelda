﻿using System;
using System.Collections.Generic;
using System.Reflection.Metadata;
using JalPals.Blocks2;
using JalPals.Doors;
using JalPals.Sprites;
using JalPals.Items;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using JalPals.Enemies;
using JalPals.Projectiles;

namespace JalPals.Rooms
{
	public class Room : IRoom
	{
        // Public properties
        public List<IBlock2> blocks { get; set; }
        public List<IDoor> doors { get; set; }
        public List<IItem> items { get; set; }
        public List<IBlock2> collideable { get; set; }
        public List<IGameObject> wallRectangles { get; set; }
        public EnemyManager enemies { get; set; }
        public ProjectileManager projectiles { get; set; }
        


        // Private variables
        private CSVParser parser = new CSVParser();             /* csv parser object */
        private Texture2D spriteSheet;                          /* sprite sheet */
        private Texture2D itemSheet;                            /* item sheet */
        private Texture2D enemySheet;                          /* sprite sheet */
        private Texture2D bossSheet;                            /* item sheet */
        private Dictionary<int, Rectangle> blockOptions;        /* dictionary of block options */
        private Dictionary<int, Rectangle> itemOptions;
        public SpriteBatch spriteBatch;
        private Vector2 roomStart;                              /* room starting position */
        private int frameYOffset = 56;                          /* y offset of frame */
        private int sc;                                         /* scale to draw dest recs */

        public Room(string filePath, ContentManager content, int scale)
        {

            blocks = new List<IBlock2>();
            doors = new List<IDoor>();
            collideable = new List<IBlock2>();
            items = new List<IItem>();
            enemies = new EnemyManager();
            projectiles = new ProjectileManager(content);

            // Initialize drawing varaibles
            this.spriteSheet = content.Load<Texture2D>("dungeon_spritesheet");
            this.itemSheet = content.Load<Texture2D>("link");
            this.enemySheet = content.Load<Texture2D>("dungeonEnemiesTransparent");
            this.bossSheet = content.Load<Texture2D>("bosses");
            this.sc = scale;
            roomStart = new Vector2(32, frameYOffset-16);

            // Initialize block options
            blockOptions = new Dictionary<int, Rectangle>()
            {
                // FloorTile
                { 0, new Rectangle(463, 0, 16, 16) },
                // SpecialTile
                { 1, new Rectangle(480, 0, 16, 16) },
                // StatieRight
                { 2, new Rectangle(497, 0, 16, 16) },
                // StatueLeft
                { 3, new Rectangle(514, 0, 16, 16) },
                // BlackTile
                { 4, new Rectangle(463, 17, 16, 16) },
                // Sand
                { 5, new Rectangle(480, 17, 16, 16) },
                // Blue
                { 6, new Rectangle(497, 17, 16, 16) },
                // Stairs
                { 7, new Rectangle(514, 17, 16, 16) },
                // GreyBricks
                { 8, new Rectangle(463, 34, 16, 16) },
                // GreyStripes
                { 9, new Rectangle(480, 34, 16, 16) },
                // Water
                {10, new Rectangle(497, 34, 16, 16) }
            };

                // Initialize item options
            itemOptions = new Dictionary<int, Rectangle>()
            {
                //bomb
                { 0, new Rectangle(364, 226, 8, 14) },
                //key
                { 1, new Rectangle(364, 255, 8, 16) },
                //RedPotion
                { 2, new Rectangle(394, 285, 8, 16) },
                //BluePotion
                { 3,  new Rectangle(424, 285, 8, 16) },
                //TriforcePiece
                { 4,  new Rectangle(333, 288, 10, 10) },
                //Map
                { 5,  new Rectangle(274, 255, 8, 16) },
                //Compass
                { 6,  new Rectangle(392, 257, 11, 12)},
                //Bow
                { 7,  new Rectangle(424, 255, 8, 16)},
                //OrangeRupee
                { 8,  new Rectangle(244, 225, 8, 16)},
                //BlueRupee
                { 9,  new Rectangle(274, 225, 8, 16)},
                //HeartDrop
                { 10,  new Rectangle(244, 199, 7, 8)},
                //HeartContainer
                { 11,  new Rectangle(301, 196, 13, 13)},
                //Boomerang
                { 12, new Rectangle(334, 256, 8, 14) },
                //Blank Enemy
                {-1, new Rectangle(400,20,1,1)}
             };

            PopulateLists(parser.Parse(filePath, ','));
        }

        private void PopulateLists(List<string[]> parseOut)
        {
            // Add frame to list
            Rectangle frameSrc = new Rectangle(0, 0, 256, 176);
            Rectangle frameDest = new Rectangle(0, sc * frameYOffset, sc * 256, sc * 176);
            blocks.Add(new Block(spriteSheet, frameSrc, frameDest, false));

            // Add doors to door list
            for (int i = 0; i < 4; i++)
            {
                // Get door code from CSV
                int c = Int32.Parse(parseOut[2][i]);

                // Get door src
                Rectangle currSrc = new Rectangle(294 + (33 * c), (33 * i), 32, 32);

                // Get door dest
                Rectangle currDest = new Rectangle(0, 0, sc*32, sc*32);
                switch (i)
                {
                    case (0):
                        // Top
                        currDest = new Rectangle(112*sc, frameYOffset*sc, sc*32, sc*32);
                        doors.Add(new Door(spriteSheet, currSrc, currDest, true, DoorSide.TOP));
                        break;
                    case (1):
                        // Left
                        currDest = new Rectangle(0, sc*(frameYOffset + 72), sc * 32, sc * 32);
                        doors.Add(new Door(spriteSheet, currSrc, currDest, true, DoorSide.LEFT));
                        break;
                    case (2):
                        // Right
                        currDest = new Rectangle(224 * sc, sc*(frameYOffset + 72), sc * 32, sc * 32);
                        doors.Add(new Door(spriteSheet, currSrc, currDest, true, DoorSide.RIGHT));
                        break;
                    case (3):
                        // Bottom
                        currDest = new Rectangle(112 * sc, sc*(frameYOffset + 144), sc * 32, sc * 32);
                        doors.Add(new Door(spriteSheet, currSrc, currDest, true, DoorSide.BOTTOM));
                        break;

                }
                // Add door to list
                
            }

            // Add blocks to list
            for (int i = 3; i < 10; i++)
            {
                for (int j = 0; j < 12; j++)
                {
                    int currCode = Int32.Parse(parseOut[i][j]);
                    Rectangle currSrc = blockOptions[currCode];
                    Rectangle currDest = new Rectangle(sc*((int)roomStart.X + 16 * j), sc*((int)roomStart.Y + 16 * i), sc*16, sc*16);
                    
                    if(currCode > 0 && currCode < 4 || currCode == 10)
                    {
                        Block newBlock = new Block(spriteSheet, currSrc, currDest, true);
                        blocks.Add(newBlock);
                        collideable.Add(newBlock);
                    }
                    else
                    {
                        Block newBlock = new Block(spriteSheet, currSrc, currDest, true);
                        blocks.Add(newBlock);
                    }
                }
            }

            wallRectangles = findCollidableWalls(this.doors);




            //add items to room
            //This line checks to see if the room as items in it.
            //If the parseOut.Count doesn't have a 10th line, then the room doesn't have items to spawn in. 
            if (parseOut.Count > 10)   
            {
                //This will be the number of items for the room. It is gotten from the length of the string of the 10th
                //line in the csv code.
                int numOfItems = parseOut[10].Length;
                for (int i = 0; i < numOfItems; i++)
                {
                    //These offsets are to allign the item properly in the square tiles on the floor.
                    float offsetX = 15;
                    float offsetY = -15;

                    //get the current item ID.
                    int currCode = Int32.Parse(parseOut[10][i]);
                    int currXPos = Int32.Parse(parseOut[11][i]);
                    int currYPos = Int32.Parse(parseOut[12][i]);
                    //Get he source rectangle for this item
                    Rectangle currSrc = itemOptions[currCode];

                    //Calculate the position of the item. The calculations are complicated, but currXPos and currYPos
                    //are the tile coordinates for the inner room. X = 0, Y = 0 is the top left corner. 
                    Vector2 currPosition = new Vector2 ((sc * 16 * (currXPos + 2)) + offsetX, (sc * 16 * (currYPos + 6)) + offsetY);

                    //Arbitrarily initialized to a BombItem
                    IItem item = new BombItem(itemSheet, currPosition, sc);

                    //Checking what kind of item the current Item really is.
                    switch(currCode)
                    {
                        case 0:
                            item = new BombItem(itemSheet, currPosition, (int)(sc * 1.5));
                            break; 
                        case 1:
                            item = new KeyItem(itemSheet, currPosition, (int)(sc * 1.5));
                            break;
                        case 2:
                            item = new RedPotionItem(itemSheet, currPosition, (int)(sc * 1.5));
                            break;
                        case 3:
                            item = new BluePotionItem(itemSheet, currPosition, (int)(sc * 1.5));
                            break;
                        case 4:
                            item = new TriforceItem(itemSheet, currPosition, (int)(sc * 1.6));
                            break;
                        case 5:
                            item = new MapItem(itemSheet, currPosition, (int)(sc * 1.5));
                            break;
                        case 6:
                            item = new CompassItem(itemSheet, currPosition, (int)(sc * 1.5));
                            break;
                        case 7:
                            item = new BowItem(itemSheet, currPosition, (int)(sc * 1.5));
                            break;
                        case 8:
                            item = new OrangeRupeeItem(itemSheet, currPosition, (int)(sc * 1.5));
                            break;
                        case 9:
                            item = new BlueRupeeItem(itemSheet, currPosition, (int)(sc * 1.5));
                            break;
                        case 10:
                            item = new HeartDropItem(itemSheet, currPosition, (int)(sc * 1.5));
                            break;
                        case 11:
                            item = new HeartContainerItem(itemSheet, currPosition, (int)(sc * 1.5));
                            break;
                        case 12:
                            item = new BoomerangItem(itemSheet, currPosition, (int)(sc * 1.5));
                            break;
                        default: 
                            break;

                    }
                    
                    //adding it to the list of items for this room.
                    items.Add(item);
                }
            }

            
            //add enemies to room
            //This line checks to see if the room as items in it.
            //If the parseOut.Count doesn't have a 12th line, then the room doesn't have enemies to spawn in. 
            if (parseOut.Count > 13)
            {
                //This will be the number of items for the room. It is gotten from the length of the string of the 10th
                //line in the csv code.
                int numOfEnemies = parseOut[13].Length;
                for (int i = 0; i < numOfEnemies; i++)
                {
                    //These offsets are to allign the enemy properly in the square tiles on the floor.
                    float offsetX = 0;
                    float offsetY = -15;

                    //get the current item ID.
                    int currCode = Int32.Parse(parseOut[13][i]);
                    int currXPos = Int32.Parse(parseOut[14][i]);
                    int currYPos = Int32.Parse(parseOut[15][i]);
                    //Get he source rectangle for this item
                    Rectangle currSrc = itemOptions[currCode];

                    //Calculate the position of the enemy. The calculations are complicated, but currXPos and currYPos
                    //are the tile coordinates for the inner room. X = 0, Y = 0 is the top left corner. 
                    Vector2 currPosition = new Vector2((sc * 16 * (currXPos + 2)) + offsetX, (sc * 16 * (currYPos + 6)) + offsetY);

                    //Arbitrarily initialized to a Keese
                    ISprite enemy = new Keese(enemySheet, currPosition);

                    //Checking what kind of enemy the current Item really is.
                    switch (currCode)
                    {
                        case 0:
                            enemy = new Keese(enemySheet, currPosition);
                            break;
                        case 1:
                            enemy = new Gel(enemySheet, currPosition);
                            break;
                        case 2:
                            enemy = new Goriya(enemySheet, currPosition, projectiles);
                            break;
                        case 3:
                            enemy = new OldMan(enemySheet, currPosition);
                            break;
                        case 4:
                            enemy = new Stalfos(enemySheet, currPosition);
                            break;
                        case 5:
                            enemy = new Aquamentus(bossSheet, currPosition, projectiles);
                            break;
                        case 6:
                            enemy = new Wallmaster(enemySheet, currPosition);
                            break;
                        case 7:
                            enemy = new Blade(enemySheet, currPosition);
                            break;

                    }

                    //adding it to the list of enemies for this room.
                    enemies.add(enemy);
                }
            }
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            foreach (IBlock2 block in blocks)
            {
                block.Draw(spriteBatch);
            }

            foreach (IDoor door in doors)
            {
                door.Draw(spriteBatch);
            }

            foreach(IItem item in items)
            {
                item.Draw(spriteBatch);
            }

            enemies.Draw(spriteBatch);
            projectiles.Draw(spriteBatch);
        }

        public void Update()
        {
            //throw new NotImplementedException();
            enemies.Update();
            projectiles.Update();
        }

        private List<IGameObject> findCollidableWalls(List<IDoor> doors)
        {
            List<IGameObject> RectGameObjects = new List<IGameObject>();

            int roomWidth = 16 * 16 * sc;
            int roomHeidth = 11 * 16 * sc;

            int roomNavWidth = 12 * 16 * sc;
            int roomNavHeidth = 7 * 16 * sc;

            
            Point origin = new Point((int)roomStart.X, (int)roomStart.Y);
            Rectangle roomRect = new Rectangle(origin.X, origin.Y, roomWidth, roomHeidth);
            Rectangle roomNavRect = new Rectangle(origin.X + 2 * 16 * sc, origin.Y + 2 * 16 * sc, roomNavWidth, roomNavHeidth); 

            bool[] sideRectFill = new bool[4]{ false, false, false, false};
            
            List<Rectangle> walls = new List<Rectangle>();

            foreach (Door door in doors)
            {
                int PIXBUFF = 5;
                Rectangle doorRect = door.destRectangle;
                Rectangle wall = new Rectangle();
                Rectangle wall2 = new Rectangle();

                // Determine the direction of the wall based on the door's position
                if (door.doorSide == DoorSide.LEFT)
                {
                    wall.X = doorRect.Left;
                    wall.Y = origin.Y;
                    wall.Width = doorRect.Width - PIXBUFF;
                    wall.Height = doorRect.Y - origin.Y;

                    wall2.X = doorRect.Left;
                    wall2.Y = doorRect.Bottom;
                    wall2.Width = doorRect.Width - PIXBUFF;
                    wall2.Height = roomRect.Bottom - doorRect.Bottom;

                    sideRectFill[0] = true;
                }
                else if (door.doorSide == DoorSide.RIGHT)
                {

                    wall.X = doorRect.Left + PIXBUFF;
                    wall.Y = origin.Y;
                    wall.Width = doorRect.Width;
                    wall.Height = doorRect.Y - origin.Y;

                    wall2.X = doorRect.Left + PIXBUFF;
                    wall2.Y = doorRect.Bottom;
                    wall2.Width = doorRect.Width;
                    wall2.Height = roomRect.Bottom - doorRect.Bottom;

                    sideRectFill[2] = true;
                }
                else if (door.doorSide == DoorSide.TOP)
                {
                    wall.X = origin.X;
                    wall.Y = doorRect.Top;
                    wall.Width = doorRect.Left;
                    wall.Height = doorRect.Height - PIXBUFF;

                    wall2.X = doorRect.Right;
                    wall2.Y = doorRect.Top;
                    wall2.Width = roomRect.Width - doorRect.Right;
                    wall2.Height = doorRect.Height - PIXBUFF;


                    sideRectFill[1] = true;

                }
                else if (door.doorSide == DoorSide.BOTTOM)
                {
                    wall.X = origin.X;
                    wall.Y = doorRect.Top + PIXBUFF;
                    wall.Width = doorRect.Left;
                    wall.Height = doorRect.Height;

                    wall2.X = doorRect.Right;
                    wall2.Y = doorRect.Top + PIXBUFF;
                    wall2.Width = roomRect.Width - doorRect.Right;
                    wall2.Height = doorRect.Height;

                    sideRectFill[3] = true;
                }
                walls.Add(wall);
                walls.Add(wall2);
            }

            if (!sideRectFill[0])
            {
                walls.Add(new Rectangle(origin.X, origin.Y, roomNavRect.X - origin.X, roomRect.Height));
            }
            if (!sideRectFill[1])
            {
                walls.Add(new Rectangle(origin.X, origin.Y, roomNavRect.X, roomNavRect.Top - roomRect.Top));
            }
            if (!sideRectFill[2])
            {
                walls.Add(new Rectangle(roomNavRect.Right, origin.Y, 1, roomRect.Height));
            }
            if (!sideRectFill[3])
            {
                walls.Add(new Rectangle(origin.X, roomNavRect.Top, roomRect.Width, 1));
            }

            /*
            // Check for intersections with other walls and adjust size if necessary
            foreach (var otherWall in walls)
            {
                if (wall.Intersects(otherWall))
                {
                    if (wall.Left == otherWall.Right)
                    {
                        // Adjust the width of the wall to not overlap with the other wall
                        wall.X += otherWall.Width;
                        wall.Width -= otherWall.Width;
                    }
                    else if (wall.Right == otherWall.Left)
                    {
                        // Adjust the width of the wall to not overlap with the other wall
                        wall.Width -= otherWall.Width;
                    }
                    else if (wall.Top == otherWall.Bottom)
                    {
                        // Adjust the height of the wall to not overlap with the other wall
                        wall.Y += otherWall.Height;
                        wall.Height -= otherWall.Height;
                    }
                    else if (wall.Bottom == otherWall.Top)
                    {
                        // Adjust the height of the wall to not overlap with the other wall
                        wall.Height -= otherWall.Height;
                    }
                }
            }

                // Check for intersection with the room and adjust size if necessary
                if (wall.Left < room.Left)
                {
                    wall.Width -= (room.Left - wall.Left);
                    wall.X = room.Left;
                }
                if (wall.Right > room.Right)
                {
                    wall.Width -= (wall.Right - room.Right);
                }
                if (wall.Top < room.Top
        */

            foreach (Rectangle rect in walls)
            {
                RectGameObjects.Add(new WallRectangle(rect));
            }
            
            return RectGameObjects;
        }

        

    }

}



