﻿using System;
using JalPals.Blocks2;
using JalPals.Doors;
using System.Collections.Generic;
using Microsoft.Xna.Framework.Graphics;

namespace JalPals.Rooms
{
	public interface IRoom
	{
		void Draw(SpriteBatch spriteBatch);

        void Update();
        List<IBlock2> collideable { get; set; }
        List<IGameObject> wallRectangles { get; set; }
        List<IDoor> doors { get; set; }
    }
}

