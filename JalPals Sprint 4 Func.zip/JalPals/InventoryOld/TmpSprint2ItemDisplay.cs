﻿using System;
using System.Reflection;

namespace JalPals.Inventory
{
	public class TmpSprint2ItemDisplay
	{
		public TmpSprint2ItemDisplay()
		{
           
            
        }
	}
}

