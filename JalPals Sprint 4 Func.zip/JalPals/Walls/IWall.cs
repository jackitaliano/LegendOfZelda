﻿using System;
namespace JalPals.Walls
{
	public interface IWall : IGameObject
	{

	}
}

