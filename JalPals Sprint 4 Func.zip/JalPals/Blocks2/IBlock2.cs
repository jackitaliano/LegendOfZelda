﻿using System;
using Microsoft.Xna.Framework.Graphics;

namespace JalPals.Blocks2
{
	public interface IBlock2 : IGameObject
	{
        void Draw(SpriteBatch spriteBatch);
    }
}

