﻿using System;
using JalPals.Blocks2;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace JalPals.Blocks2
{
    public class Block : IBlock2
    {
        // Public properties
        public Rectangle destRectangle { get; set; }
        public Rectangle collisionRectangle { get; set; }
        public Rectangle srcRectangle { get; set; }
        public Vector2 velocityVector { get; set; }
        public bool collidable { get; set; }

        // Private variables
        Texture2D spriteSheet;

        // Debug code
        Texture2D whiteRectangle;

        public Block(Texture2D spriteSheet, Rectangle src, Rectangle dest, bool collidable)
        {
            this.spriteSheet = spriteSheet;
            this.destRectangle = dest;
            this.srcRectangle = src;
            this.collidable = collidable;
            Rectangle newCollide = new Rectangle(destRectangle.X, destRectangle.Y, destRectangle.Width, destRectangle.Height - 24);
            collisionRectangle = newCollide;
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(this.spriteSheet, destRectangle, srcRectangle, Color.White);
        }


        public GameObjectType getType()
        {
            Console.WriteLine("Get block type.");
            return GameObjectType.BLOCK;

        }

        public void ResolveCollision(IGameObject obj, int side)
        {
            Console.WriteLine("Resolve block colission.");
        }
    }
}

