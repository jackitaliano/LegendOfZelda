﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;

namespace JalPals.Items;

public struct ItemSlots
{
    public ItemSlots() { }

    public static Rectangle Slot1 = new Rectangle(500, 50, 16, 28);

    public static Rectangle Slot2 = new Rectangle(530, 50, 16, 28);

    public static Rectangle Slot3 = new Rectangle(560, 50, 16, 28);

    public static Rectangle Slot4 = new Rectangle(590, 50, 16, 28);
}

