﻿using System;
using System.Collections.Generic;
using System.Reflection;
using JalPals.Player;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace JalPals.Inventory
{
	public class TmpSprint2ItemDisplay
	{
		public TmpSprint2ItemDisplay(SpriteBatch spriteBatch)
		{
           
            
        }
	}
}

