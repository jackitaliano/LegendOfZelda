﻿
#!/bin/sh

export PATH=/usr/local/share/dotnet/x64:$PATH
dotnet build
