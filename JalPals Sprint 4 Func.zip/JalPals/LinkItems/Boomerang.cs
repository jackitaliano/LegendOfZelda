﻿using System;
namespace JalPals.LinkItems
{
	public class Boomerang
	{
		public Boomerang()
		{
		}
	}
}

