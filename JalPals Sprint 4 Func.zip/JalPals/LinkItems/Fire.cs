﻿using System;
namespace JalPals.LinkItems
{
	public class Fire
	{
		public Fire()
		{
		}
	}
}

