﻿using System;
namespace JalPals.LinkItems
{
	public class ArrowDown
	{
		public ArrowDown()
		{
		}
	}
}

