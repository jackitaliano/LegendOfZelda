﻿using System;
namespace JalPals.LinkItems
{
	public class Bomb
	{
		public Bomb()
		{
		}
	}
}

