﻿using System;
namespace JalPals.LinkItems
{
	public class ArrowLeft
	{
		public ArrowLeft()
		{
		}
	}
}

