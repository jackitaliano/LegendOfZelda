﻿using System;
namespace JalPals.LinkItems
{
	public class ArrowUp
	{
		public ArrowUp()
		{
		}
	}
}

