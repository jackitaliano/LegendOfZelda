﻿using System;
namespace JalPals.LinkItems
{
	public interface IDroppable
	{
	}
}

