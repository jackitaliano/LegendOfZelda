﻿using System;
namespace JalPals.LinkItems
{
	public struct LinkItemAnimations
	{
	}
}

