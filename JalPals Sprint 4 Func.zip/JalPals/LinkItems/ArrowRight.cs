﻿using System;
namespace JalPals.LinkItems
{
	public class ArrowRight
	{
		public ArrowRight()
		{
		}
	}
}

