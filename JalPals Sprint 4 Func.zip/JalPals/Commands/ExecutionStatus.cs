﻿using System;
namespace JalPals.Commands
{
	public enum ExecutionStatus
	{
		Pending,
		Successful,
		Failed,
		Critical,
	}
}

