﻿using System;
namespace JalPals.Commands
{
    public class SwapItemLeft : ICommand
    {
        public ExecutionStatus Status { get; set; }
        private Game1 game;

        public SwapItemLeft(Game1 game)
        {
            this.game = game;
        }

        public void Execute()
        {
            game.Link.LinkInventory.PreviousItem();
        }
    }
}


