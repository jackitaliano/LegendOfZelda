﻿using System;
namespace JalPals.Commands
{
    public class NextEnemy : ICommand
    {
        public ExecutionStatus Status { get; set; }

        Game1 game;
        public NextEnemy(Game1 game)
        {
            this.game = game;
        }

        public void Execute()
        {
            game.enemySwitcher.Next();
        }
    }
}

