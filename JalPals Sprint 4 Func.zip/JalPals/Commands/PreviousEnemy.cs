﻿using System;
namespace JalPals.Commands
{
	public class PreviousEnemy : ICommand
	{
        public ExecutionStatus Status { get; set; }

        Game1 game;
		public PreviousEnemy(Game1 game)
		{
			this.game = game;
		}

		public void Execute()
		{
			game.enemySwitcher.Previous();
		}
	}
}

