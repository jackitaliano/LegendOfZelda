﻿using System;
namespace JalPals.Commands
{
    public class PreviousRoom : ICommand
    {
        public ExecutionStatus Status { get; set; }

        Game1 game;
        public PreviousRoom(Game1 game)
        {
            this.game = game;
        }

        public void Execute()
        {
            game.roomManager.Previous();
        }
    }
}

