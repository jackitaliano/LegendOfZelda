﻿using System;
namespace JalPals.Commands
{
    public class NextRoom : ICommand
    {
        public ExecutionStatus Status { get; set; }

        Game1 game;
        public NextRoom(Game1 game)
        {
            this.game = game;
        }

        public void Execute()
        {
            game.roomManager.Next();
        }
    }
}

