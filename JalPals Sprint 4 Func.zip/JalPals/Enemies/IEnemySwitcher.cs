﻿using System;
using JalPals.Sprites;
using Microsoft.Xna.Framework.Graphics;

namespace JalPals.Enemies
{
	public interface IEnemySwitcher
	{
		public ISprite currentEnemy { get; set; }
        void Next();
		void Previous();
		void Update();
		void Draw(SpriteBatch spriteBatch);
		void Switch();
    }

}

