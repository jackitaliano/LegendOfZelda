﻿using System;
using System.Collections.Generic;
using System.Reflection.Metadata;
using JalPals.Sprites;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using JalPals.Projectiles;

namespace JalPals.Enemies
{
	public class EnemySwitcher : IEnemySwitcher
	{
		public ISprite currentEnemy { get; set; }
		// Private variables
		private int index;
		private ISprite[] enemies;
		private Texture2D enemyTexture;
        private Texture2D bossTexture;
        private int totalEnemies;
		private Vector2 initialPos;
        public Rectangle destRectangle { get; }


        public EnemySwitcher(ContentManager content, Vector2 initial, IProjectileManager projectileManager)
		{
			enemyTexture = content.Load<Texture2D>("dungeonEnemiesTransparent");
            bossTexture = content.Load<Texture2D>("bosses");
            index = 0;
			initialPos = initial;
			enemies = new ISprite[]
			{
				new OldMan(enemyTexture, initial),
				new Keese(enemyTexture, initial),
				new Stalfos(enemyTexture, initial),
				new Gel(enemyTexture, initial),
				new Aquamentus(bossTexture, initial, projectileManager),
				new Goriya(enemyTexture, initial, projectileManager)
			};
			totalEnemies = enemies.Length;
			currentEnemy = enemies[index];
		}

		public void Next()
		{
            if (index == totalEnemies - 1)
			{
				index = 0;
			}
			else
			{
				index++;
			}
			this.Switch();
		}

		public void Previous()
		{

            if (index == 0)
            {
                index = totalEnemies - 1;
            }
            else
            {
                index--;
            }
			this.Switch();
        }

		public void Switch()
		{
            currentEnemy = enemies[index];
			currentEnemy.Position = initialPos;
        }

		public void Draw(SpriteBatch spriteBatch)
		{
			//currentEnemy.Draw(spriteBatch);
		}

        public void Update()
        {
			currentEnemy.Update();
        }
    }
}

