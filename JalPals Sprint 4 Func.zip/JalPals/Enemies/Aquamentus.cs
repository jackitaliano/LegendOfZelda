﻿using System;
using JalPals.Sprites;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using JalPals.Projectiles;

namespace JalPals.Enemies
{
    public class Aquamentus : ISprite
    {
        // Properties
        public Texture2D spriteSheet { get; set; }
        public Vector2 Position { get; set; }

        public Rectangle destRectangle { get; set; }
        public Rectangle collisionRectangle { get; set; }
        public Vector2 velocityVector { get; set; }

        // Private variables
        private int animationFrame;
        private int speed = 2;
        private int scale = 3;
        private int currDirection;
        private Rectangle srcRec, destRec;
        private Random rnd = new Random(Guid.NewGuid().GetHashCode());
        private IProjectileManager projManager;

        public Aquamentus(Texture2D spriteSheet, Vector2 position, IProjectileManager projectileManager)
        {
            this.Position = position;
            this.spriteSheet = spriteSheet;
            this.projManager = projectileManager;
            destRectangle = new Rectangle((int)Position.X, (int)Position.Y, srcRec.Width, srcRec.Height);
            collisionRectangle = destRec;
        }

        public void Update()
        {
            animationFrame++;

            destRectangle = new Rectangle((int)Position.X, (int)Position.Y, srcRec.Width * scale, srcRec.Height * scale);
            collisionRectangle = destRectangle;

            //Get a direction for the Aqamentus
            if (animationFrame == 20)
            {
                currDirection = rnd.Next(0, 4);
            }

            //Have the aquamentis walk in that direction for 50 frames.
            if (animationFrame > 20 && animationFrame < 70)
            {
                switch (currDirection)
                {
                    case 0:
                        this.Position += new Vector2(speed, 0);
                        break;
                    case 1:
                        this.Position += new Vector2(-speed, 0);
                        break;
                    case 2:
                        this.Position += new Vector2(0, speed);
                        break;
                    case 3:
                        this.Position += new Vector2(0, -speed);
                        break;
                }
            }

            //Get a new drection 
            if (animationFrame == 70)
            {
                currDirection = rnd.Next(0, 4);
            }

            //Have the aquamentus walk in that direction for 50 frames.
            if (animationFrame > 70 && animationFrame < 120)
            {
                switch (currDirection)
                {
                    case 0:
                        this.Position += new Vector2(speed, 0);
                        break;
                    case 1:
                        this.Position += new Vector2(-speed, 0);
                        break;
                    case 2:
                        this.Position += new Vector2(0, speed);
                        break;
                    case 3:
                        this.Position += new Vector2(0, -speed);
                        break;
                }
            }

            //Every 120 frames, stop and fire the fireballs. Reset animation frames to 0.
            if (animationFrame == 120)
            {
                Vector2 fireSrc = new Vector2(this.Position.X, this.Position.Y + 15);
                this.projManager.AddFireball(fireSrc, new Vector2(-5, 0), false);
                this.projManager.AddFireball(fireSrc, new Vector2(-5, -2), false);
                this.projManager.AddFireball(fireSrc, new Vector2(-5, 2), false);
                animationFrame = 0;
            }

            destRectangle = new Rectangle((int)Position.X, (int)Position.Y, srcRec.Width * scale, srcRec.Height * scale);
            collisionRectangle = destRec;
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            int destX;
            int destY;

            if (animationFrame % 2 == 0)
            {
                srcRec = new Rectangle(51, 11, 24, 32);
                destX = (int)this.Position.X;
                destY = (int)this.Position.Y;
                destRectangle = new Rectangle(destX, destY, srcRec.Width*scale, srcRec.Height*scale);
            }
            else
            {
                srcRec = new Rectangle(76, 11, 24, 32);
                destX = (int)this.Position.X;
                destY = (int)this.Position.Y;
                destRectangle = new Rectangle(destX, destY, srcRec.Width * scale, srcRec.Height * scale);
            }
            spriteBatch.Draw(this.spriteSheet, destRectangle, srcRec, Color.White);
        }

        public GameObjectType getType()
        {
            return GameObjectType.ENEMY;
        }

        private void TakeDamage()
        {
            // take damage
        }

        public void ResolveCollision(IGameObject obj1, int side)
        {

            GameObjectType type = obj1.getType();
            switch (type)
            {
                case GameObjectType.LINK:
                    CollisionRebound(side);
                    break;
                case GameObjectType.ENEMY:
                    CollisionRebound(side);
                    break;
                case GameObjectType.ENEMYPROJECTILE:
                    break;
                case GameObjectType.LINKPROJECTILE:
                    TakeDamage();
                    break;
                case GameObjectType.ITEM:
                    break;
                case GameObjectType.BLOCK:
                    CollisionRebound(side);
                    break;
            }
        }

        private void CollisionRebound(int side)
        {
            switch (side)
            {
                case 1: // Top side
                    Position = new Vector2(Position.X, Position.Y + velocityVector.Y);
                    break;
                case 2: // Right side
                    Position = new Vector2(Position.X - velocityVector.X, Position.Y);
                    break;
                case 3: // Bottom side
                    Position = new Vector2(Position.X, Position.Y - velocityVector.Y);
                    break;
                case 4: // Left side
                    Position = new Vector2(Position.X + velocityVector.X, Position.Y);
                    break;
            }
        }
    }

}

