﻿using System;
using JalPals.Projectiles;
using JalPals.Sprites;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace JalPals.Enemies
{
    public class Goriya : ISprite
    {
        // Properties
        public Texture2D spriteSheet { get; set; }
        public Vector2 Position { get; set; }

        public Rectangle destRectangle { get; set; }
        public Rectangle collisionRectangle { get; set; }
        public Vector2 velocityVector { get; set; }

        // Private variables
        private int animationFrame;
        private int currDirection;
        private int speed = 1;
        private int scale = 3;
        private Rectangle[] sourceRecs;
        private Rectangle srcRec, destRec;
        private Random rnd = new Random();
        private bool isThrowing;
        private IProjectileManager projManager;
        private Vector2 boomSrc;

        public Goriya(Texture2D spriteSheet, Vector2 position, IProjectileManager projectileManager)
        {
            this.Position = position;
            this.spriteSheet = spriteSheet;
            this.projManager = projectileManager;
            this.currDirection = rnd.Next(0, 4);
            destRectangle = new Rectangle((int)Position.X, (int)Position.Y, srcRec.Width, srcRec.Height);
            collisionRectangle = destRectangle;
            sourceRecs = new Rectangle[]
            {
                new Rectangle(257, 11, 13, 16),
                new Rectangle(275, 12, 14, 15),

                new Rectangle(257, 29, 13, 16),
                new Rectangle(275, 30, 14, 15),

                new Rectangle(241, 11, 13, 16),
                new Rectangle(241, 29, 13, 16),

                new Rectangle(224, 11, 13, 16),
                new Rectangle(224, 29, 13, 16),
            };
        }

        public void Update()
        {
            animationFrame++;

            destRectangle = new Rectangle((int)Position.X, (int)Position.Y, srcRec.Width * scale, srcRec.Height * scale);
            collisionRectangle = destRectangle;

            if (animationFrame >= 240)
            {
                animationFrame = 0;
            }

            if(animationFrame % 60 == 0)
            {
                currDirection = rnd.Next(0, 4);
                if (currDirection < 2 && rnd.Next(0, 2) == 1)
                {
                    isThrowing = true;

                    if(currDirection == 0)
                    {
                        boomSrc = new Vector2(this.Position.X + srcRec.Width, this.Position.Y + 15);
                        projManager.AddBoomerang(boomSrc, new Vector2(5, 0), false);
                        
                    }
                    else
                    {
                        boomSrc = new Vector2(this.Position.X, this.Position.Y + 15);
                        projManager.AddBoomerang(boomSrc, new Vector2(-5, 0), false);
                    }

                }
                else
                {
                    isThrowing = false;
                }

            }
            
            switch (currDirection)
            {
                case 0:
                    if (!isThrowing)
                    {
                        this.Position += new Vector2(speed, 0);
                    }
                    break;
                case 1:
                    if (!isThrowing)
                    {
                        this.Position += new Vector2(-speed, 0);
                    }
                    break;
                case 2:
                    this.Position += new Vector2(0, -speed);
                    break;
                case 3:
                    this.Position += new Vector2(0, speed);
                    break;
            }

        }

        public void Draw(SpriteBatch spriteBatch)
        {
            int destX;
            int destY;

            if (animationFrame % 2 == 0)
            {
                srcRec = sourceRecs[2 * currDirection];
                destX = (int)this.Position.X;
                destY = (int)this.Position.Y;
                destRec = new Rectangle(destX, destY, srcRec.Width*scale, srcRec.Height*scale);
            }
            else
            {
                srcRec = sourceRecs[2 * currDirection + 1];
                destX = (int)this.Position.X;
                destY = (int)this.Position.Y;
                destRec = new Rectangle(destX, destY, srcRec.Width * scale, srcRec.Height * scale);
            }

            spriteBatch.Draw(this.spriteSheet, destRec, srcRec, Color.White);
        }

        public GameObjectType getType()
        {
            return GameObjectType.ENEMY;
        }

        private void TakeDamage()
        {
            // take damage
        }

        public void ResolveCollision(IGameObject obj1, int side)
        {

            GameObjectType type = obj1.getType();
            switch (type)
            {
                case GameObjectType.LINK:
                    CollisionRebound(side);
                    break;
                case GameObjectType.ENEMY:
                    CollisionRebound(side);
                    break;
                case GameObjectType.ENEMYPROJECTILE:
                    break;
                case GameObjectType.LINKPROJECTILE:
                    TakeDamage();
                    break;
                case GameObjectType.ITEM:
                    break;
                case GameObjectType.BLOCK:
                    CollisionRebound(side);
                    break;
            }
        }

        private void CollisionRebound(int side)
        {
            switch (side)
            {
                case 1: // Top side
                    Position = new Vector2(Position.X, Position.Y + velocityVector.Y);
                    break;
                case 2: // Right side
                    Position = new Vector2(Position.X - velocityVector.X, Position.Y);
                    break;
                case 3: // Bottom side
                    Position = new Vector2(Position.X, Position.Y - velocityVector.Y);
                    break;
                case 4: // Left side
                    Position = new Vector2(Position.X + velocityVector.X, Position.Y);
                    break;
            }
        }

    }

}

