﻿using System;
using System.Collections.Generic;
using System.Reflection.Metadata;
using JalPals.Sprites;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using JalPals.Projectiles;

namespace JalPals.Enemies
{
    public class EnemyManager
    {
        public List<ISprite> roomEnemies = new List<ISprite>();
        public int numEnemies;

        public EnemyManager()
        {
            numEnemies = 0;
        }

        public void remove(ISprite enemy)
        {
            roomEnemies.Remove(enemy);
            numEnemies--;

        }

        public void add(ISprite enemy)
        {
            roomEnemies.Add(enemy);
            numEnemies++;
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            foreach (ISprite enemy in roomEnemies)
            {
                enemy.Draw(spriteBatch);
            }

        }
        public void Update()
        {
            foreach (ISprite enemy in roomEnemies)
            {
                enemy.Update();
            }
        }
    }
}

