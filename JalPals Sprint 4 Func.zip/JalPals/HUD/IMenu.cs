﻿using System;
using Microsoft.Xna.Framework.Graphics;

namespace JalPals.HUD
{
	public interface IMenu
	{
        void Draw(SpriteBatch spriteBatch);
    }
}

