﻿using System;
using System.Reflection.Metadata;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;

namespace JalPals.HUD
{
	public class Menu : IMenu
	{
        private Texture2D spriteSheet;
        private SpriteFont gameFont;

        private int rupeeCount;
        private int keyCount;
        private int bombCount;


		public Menu(ContentManager content)
		{
            this.spriteSheet = content.Load<Texture2D>("HUD");
            this.gameFont = content.Load<SpriteFont>("Zelda");
            rupeeCount = 0;
            keyCount = 0;
            bombCount = 0;
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            Vector2 position = new Vector2(75, 50);
            spriteBatch.DrawString(gameFont, "LEVEL-1", position, Color.White, 0, new Vector2(0, 0), 1.25f, SpriteEffects.None, 0.5f);

            position = new Vector2(575, 50);
            spriteBatch.DrawString(gameFont, "-LIFE-", position, Color.Red, 0, new Vector2(0, 0), 1.25f, SpriteEffects.None, 0.5f);

            position = new Vector2(290, 52);
            spriteBatch.DrawString(gameFont, "X"+rupeeCount, position, Color.White, 0, new Vector2(0, 0), 1.5f, SpriteEffects.None, 0.5f);

            position = new Vector2(290, 100);
            spriteBatch.DrawString(gameFont, "X"+keyCount, position, Color.White, 0, new Vector2(0, 0), 1.5f, SpriteEffects.None, 0.5f);

            position = new Vector2(290, 126);
            spriteBatch.DrawString(gameFont, "X"+bombCount, position, Color.White, 0, new Vector2(0, 0), 1.5f, SpriteEffects.None, 0.5f);

            Rectangle srcRec = new Rectangle(0, 0, 154, 64);
            Rectangle destRec = new Rectangle(264, 50, 231, 96);
            spriteBatch.Draw(spriteSheet, destRec, srcRec, Color.White);

        }

        public void UpdateRupee(int num)
        {
            rupeeCount += num;
        }

        public void UpdateKey(int num)
        {
            keyCount += num;
        }

        public void UpdateBomb(int num)
        {
            bombCount += num;
        }
    }
}

