# JalPals
CSE 3902 Interactive Systems Project: The Legend of Zelda

## Controls
### Player controls
- Movement: WASD and arrow keys
- Sword: Z and N
- Items: 1, 2, 3, 4
- Damage Link: E

### Block/obstacle controls
- Cycle blocks: T and Y

### Item controls
- Cycle items: U and I

### Enemy/NPC (other character) controls
- Cycle enemies: O and P

### Other controls
- Quit: Q
- Reset game: R

## Known Bugs
